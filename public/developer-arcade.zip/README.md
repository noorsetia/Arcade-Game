# Noor Developer Arcade — Neon Edition

A React arcade featuring 15 mini games, built with JavaScript, React, and Vite.

## Run locally

Requirements: Node.js 20.19+ or 22.12+.

```sh
npm install
npm run dev
```

Open the local URL printed by Vite. To create a production build, run `npm run build`.

The React application lives in `src/`; all app and backend source files use JavaScript (`.js` or `.jsx`).
