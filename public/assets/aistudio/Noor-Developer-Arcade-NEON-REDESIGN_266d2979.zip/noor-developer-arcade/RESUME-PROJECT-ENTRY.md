## Developer Arcade | React, Vite, JavaScript, CSS
- Built a responsive browser arcade with 8 mini-games spanning action, coding knowledge, logic, number puzzles, reaction speed, and working memory.
- Implemented interactive game state, keyboard/touch controls, score tracking, feedback, and persistent personal-best records using localStorage.
- Improved discoverability with live game search, category filters, responsive game cards, and hash-based navigation.

**Project link:** Add the deployed Vercel URL after validating the production build.
