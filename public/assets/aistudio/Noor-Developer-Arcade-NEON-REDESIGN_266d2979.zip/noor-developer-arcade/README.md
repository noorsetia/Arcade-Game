# Noor Setia — Developer Arcade 🎮

A responsive, interactive developer playground built with React and Vite. Eight mini-games combine arcade action, coding knowledge, logic puzzles, number strategy, reaction speed, and working-memory training.

## Games

1. **Snake** — classic grid-based survival with keyboard controls and a personal best.
2. **Space Shooter** — dodge and shoot through an arcade-style space challenge.
3. **Code Quiz** — JavaScript, React, CSS, and web fundamentals with instant explanations.
4. **Memory Match** — pair up tech-themed cards and improve your recall.
5. **Brain Teasers** — lateral thinking, number patterns, and logic questions with explanations.
6. **2048** — merge matching number tiles and plan several moves ahead.
7. **Reaction Test** — measure reaction time, avoid false starts, and save your personal best.
8. **Number Recall** — memorise increasingly long digit sequences.

## Product highlights

- Refined dark, neon-accented UI with responsive layouts and hover/focus states.
- Search and category filters to discover games quickly.
- Individual game screens with an easy return-to-arcade flow and hash URLs.
- Local personal-best persistence for applicable games; no backend or account required.
- Keyboard-friendly controls and mobile touch controls where applicable.
- Built with React, Vite, CSS, and Lucide icons.

## Run locally

Requires Node.js 20.19+ (or a compatible current LTS version).

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Production build

```bash
npm run build
npm run preview
```

## Deploy to Vercel

1. Push this folder to a GitHub repository.
2. In Vercel, import the repository.
3. Select **Vite**, set build command to `npm run build`, and output directory to `dist`.
4. Deploy. No environment variables are required.

## Resume-ready project entry

**Developer Arcade | React, Vite, JavaScript, CSS**
- Built and polished a responsive browser-based arcade featuring 8 interactive games across action, logic, memory, and puzzle categories.
- Implemented game state, keyboard/touch interactions, scoring, feedback, reaction-time measurement, number-grid mechanics, and local personal-best persistence.
- Added searchable game discovery, category filters, responsive layouts, and shareable hash-based game routes.

**Portfolio description:** A gamified developer playground that turns logic, coding knowledge, memory, and reflex training into eight playable browser experiences.

## Suggested links for your resume

- **Live Demo:** `https://YOUR-ARCADE.vercel.app/`
- **Source Code:** `https://github.com/YOUR-USERNAME/noor-developer-arcade`

Replace the placeholders after deployment. Do not list a live URL until it is deployed and tested.


## Visual refresh
The Neon Playground edition adds a redesigned left-aligned cinematic hero, animated aurora/orbit elements, gradient CTA, glass-style stats and filters, animated game cards, responsive layouts, and reduced-motion accessibility support.
